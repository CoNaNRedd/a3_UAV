class Promoted_Voice{
  name = "Promoted_Voice";
  sound[] = { "Sounds\Ranks\Promoted_Voice.ogg", 1, 1, 100 };
  titles[] = { 0, "" };
};
class Promoted_Sfx{
  name = "Promoted_Sfx";
  sound[] = { "Sounds\Ranks\Promoted_Sfx.ogg", 1, 1, 100 };
  titles[] = { 0, "" };
};
class Demoted_Voice{
  name = "Demoted_Voice";
  sound[] = { "Sounds\Ranks\Demoted_Voice.ogg", 1, 1, 100 };
  titles[] = { 0, "" };
};
class Demoted_Sfx{
  name = "Demoted_Sfx";
  sound[] = { "Sounds\Ranks\Demoted_Sfx.ogg", 1, 1, 100 };
  titles[] = { 0, "" };
};