class COMPASS_RscControlsGroup{
  idc = -1;
  type = 15;
  style = 16;
  x = 0;
  y = 0;
  w = 0;
  h = 0;
  shadow = 0;
  deletable = 0;
  fade = 0;
  colorText[] = {0,0,0,0};
  colorBackground[] = {0,0,0,0};
  font = "RobotoCondensedLight";
  sizeEx = 0.05;
  text = "";
  class ScrollBar{
    width = 0;
    color[] = {1,1,1,1};
    autoScrollEnabled = 0;
    colorActive[] = {1,1,1,1};
    colorDisabled[] = {1,1,1,0.3};
    thumb = "\A3\ui_f\data\gui\cfg\scrollbar\thumb_ca.paa";
    arrowEmpty = "\A3\ui_f\data\gui\cfg\scrollbar\arrowEmpty_ca.paa";
    arrowFull = "\A3\ui_f\data\gui\cfg\scrollbar\arrowFull_ca.paa";
    border = "\A3\ui_f\data\gui\cfg\scrollbar\border_ca.paa";
    shadow = 0;
    scrollSpeed = 0.06;
    height = 0;
    autoScrollSpeed = -1;
    autoScrollDelay = 5;
    autoScrollRewind = 0;
  };
  class VScrollbar: ScrollBar{
    color[] = {1,1,1,0};
    width = 0;
    height = 0;
    autoScrollEnabled = 0;
  };
  class HScrollbar: ScrollBar{
    color[] = {1,1,1,0};
    width = 0;
    height = 0;
    autoScrollEnabled = 0;
  };
  class Controls{};
};