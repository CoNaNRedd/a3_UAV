
class Params{
  class DatabaseType{
    title = "Database Type";
    values[] = { 0, 1, 2 };
    texts[] = { "PROFILENAMESPACE", "INIDB2", "EXTDB3" };
    default = 0;
  };
  class EnableExtOpts{
    title = "Extended Options";
    values[] = { 1, 0 };
    texts[] = { "Enabled", "Disabled" };
    default = 1;
  };
  class ResetDB{
    title = "Reset Database";
    values[] = { 1, 0 };
    texts[] = { "YES", "NO" };
    default = 0;
  };
};
