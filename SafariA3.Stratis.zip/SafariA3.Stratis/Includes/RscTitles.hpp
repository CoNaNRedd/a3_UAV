class Default{
  idd = -1;
  fadein = 0;
  fadeout = 0;
  duration = 0;
};
class RscEmptyTitleDisplay{
  idd = -1;
  movingEnable = true;
  objects[] = {};
  duration = 1e+011;
  onLoad = "uiNamespace setVariable ['RscEmptyTitleDisplay', _this select 0]";
  onUnload = "";
  controlsBackground[] = {};
  controls[] = {};
};